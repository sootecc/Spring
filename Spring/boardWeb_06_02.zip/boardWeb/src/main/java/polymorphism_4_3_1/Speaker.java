package polymorphism_4_3_1;

public interface Speaker {
	
	void volumeUp();
	void volumeDown();

}
