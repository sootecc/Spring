package polymorphism_4_2_2;

public interface Speaker {
	
	void volumeUp();
	void volumeDown();

}
